from django.contrib import admin
from .models import TypingResult


@admin.register(TypingResult)
class TypingResultAdmin(admin.ModelAdmin):
    list_display = ("name", "wpm", "accuracy", "errors", "difficulty", "duration", "ai", "created_at")
    list_filter = ("difficulty", "duration", "ai")
    search_fields = ("name",)
