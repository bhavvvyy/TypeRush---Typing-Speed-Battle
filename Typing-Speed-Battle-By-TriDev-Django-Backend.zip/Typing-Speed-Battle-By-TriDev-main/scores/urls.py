from django.urls import path
from .views import ClearResultsView, ResultDetailView, ResultListCreateView

urlpatterns = [
    path("results/", ResultListCreateView.as_view(), name="results-list-create"),
    path("results/<int:pk>/", ResultDetailView.as_view(), name="results-detail"),
    path("results/clear/", ClearResultsView.as_view(), name="results-clear"),
]
