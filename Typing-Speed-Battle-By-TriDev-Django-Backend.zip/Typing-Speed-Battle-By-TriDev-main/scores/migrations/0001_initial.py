from django.db import migrations, models


class Migration(migrations.Migration):
    initial = True
    dependencies = []
    operations = [
        migrations.CreateModel(
            name="TypingResult",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("name", models.CharField(default="Player", max_length=18)),
                ("wpm", models.FloatField(default=0)),
                ("accuracy", models.FloatField(default=1)),
                ("errors", models.PositiveIntegerField(default=0)),
                ("difficulty", models.CharField(default="medium", max_length=10)),
                ("duration", models.PositiveIntegerField(default=60)),
                ("ai", models.BooleanField(default=False)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
            ],
            options={"ordering": ["-wpm", "-accuracy", "errors", "-created_at"]},
        ),
    ]
