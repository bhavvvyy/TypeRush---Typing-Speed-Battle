from django.db import models


class TypingResult(models.Model):
    name = models.CharField(max_length=18, default="Player")
    wpm = models.FloatField(default=0)
    accuracy = models.FloatField(default=1)
    errors = models.PositiveIntegerField(default=0)
    difficulty = models.CharField(max_length=10, default="medium")
    duration = models.PositiveIntegerField(default=60)
    ai = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-wpm", "-accuracy", "errors", "-created_at"]

    def __str__(self):
        return f"{self.name} - {round(self.wpm)} WPM"
