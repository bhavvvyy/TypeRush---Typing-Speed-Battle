from rest_framework import serializers
from .models import TypingResult


class TypingResultSerializer(serializers.ModelSerializer):
    ts = serializers.SerializerMethodField()
    acc = serializers.FloatField(source="accuracy")

    class Meta:
        model = TypingResult
        fields = ["id", "name", "wpm", "acc", "errors", "difficulty", "duration", "ai", "ts"]
        read_only_fields = ["id", "ts"]

    def get_ts(self, obj):
        return int(obj.created_at.timestamp() * 1000)

    def validate_name(self, value):
        value = value.strip() or "Player"
        return value[:18]

    def validate_wpm(self, value):
        if value < 0 or value > 500:
            raise serializers.ValidationError("WPM must be between 0 and 500.")
        return value

    def validate_acc(self, value):
        if value < 0 or value > 1:
            raise serializers.ValidationError("Accuracy must be between 0 and 1.")
        return value
