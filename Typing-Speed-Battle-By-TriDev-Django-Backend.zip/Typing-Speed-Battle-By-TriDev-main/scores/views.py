from django.shortcuts import render
from rest_framework import generics, status
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework.views import APIView

from .models import TypingResult
from .serializers import TypingResultSerializer


def home(request):
    return render(request, "index.html")


class ResultListCreateView(generics.ListCreateAPIView):
    queryset = TypingResult.objects.all()
    serializer_class = TypingResultSerializer
    permission_classes = [AllowAny]
    authentication_classes = []


class ResultDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = TypingResult.objects.all()
    serializer_class = TypingResultSerializer
    permission_classes = [AllowAny]
    authentication_classes = []


class ClearResultsView(APIView):
    permission_classes = [AllowAny]
    authentication_classes = []

    def delete(self, request):
        TypingResult.objects.all().delete()
        return Response({"message": "Leaderboard cleared."}, status=status.HTTP_204_NO_CONTENT)
